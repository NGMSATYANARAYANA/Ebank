package com.bank2.ServiceConstants;

public interface RegistrationConstantsUtil {
	
	public static final String SUBMITTED = "S";
	public static final String APPROVED = "A";
	public static final String REJECTED = "R";

}
